# multiagenthandson

Hands on link:  
https://codelabs.developers.google.com/codelabs/create-multi-agents-adk-a2a?hl=ja\#1

Resources  
[https://codelabs.developers.google.com/instavibe-adk-multi-agents/instructions\#0](https://codelabs.developers.google.com/instavibe-adk-multi-agents/instructions#0)

[https://google.github.io/adk-docs/](https://google.github.io/adk-docs/)

[https://a2a-protocol.org/latest/](https://a2a-protocol.org/latest/)




